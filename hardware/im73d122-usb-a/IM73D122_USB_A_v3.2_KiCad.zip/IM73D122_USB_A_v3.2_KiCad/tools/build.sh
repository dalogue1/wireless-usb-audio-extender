#!/bin/sh
# Rebuilds everything: board -> zone refill + DRC -> panel -> Gerbers/drill zips -> previews.
# Needs KiCad 7 (pcbnew Python + kicad-cli), KiKit 1.6 on python3.12, gerbonara + rsvg-convert
# for the previews.
set -e
cd "$(dirname "$0")/.."
B=IM73D122_USB_A
PY=/usr/bin/python3.12

# 1. board
rm -rf "$B/$B.kicad_pcb" "$B/$B.kicad_pro" "$B/$B.kicad_prl" "$B/im73d122_usb.pretty" "$B/fp-lib-table"
mkdir -p "$B"
$PY tools/make_board.py "$B/$B.kicad_pcb" > /dev/null
$PY tools/refill.py "$B/$B.kicad_pcb" build/drc_board.txt
# 2. panel
tools/make_panel.sh > /dev/null
$PY - <<'EOF'
import pcbnew
b = pcbnew.LoadBoard("IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb")
pcbnew.WriteDRCReport(b, "build/drc_panel.txt", pcbnew.EDA_UNITS_MILLIMETRES, True)
EOF
# 3. Gerbers + drill
export_set() { # pcb name
  out=build/gerbers_$2
  rm -rf "$out" && mkdir -p "$out"
  kicad-cli pcb export gerbers -o "$out/" --subtract-soldermask \
    -l F.Cu,B.Cu,F.Mask,B.Mask,F.Silkscreen,B.Silkscreen,Edge.Cuts "$1" > /dev/null
  kicad-cli pcb export drill -o "$out/" --format excellon --excellon-separate-th \
    --excellon-units mm "$1" > /dev/null
  (cd "$out" && rm -f "../$2_gerbers.zip" && zip -q "../$2_gerbers.zip" *)
}
export_set "$B/$B.kicad_pcb" "$B"
export_set "IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb" "${B}_panel"
mkdir -p gerbers && cp "build/${B}_gerbers.zip" "build/${B}_panel_gerbers.zip" gerbers/
echo "built: gerbers/${B}_gerbers.zip gerbers/${B}_panel_gerbers.zip"
grep -E "Found" build/drc_board.txt build/drc_panel.txt
