#!/usr/bin/env python3
"""Builds IM73D122_USB_A.kicad_pcb: an IM73D122 PDM mic module on a small PCB with a
soldered-on USB-A plug (Molex 48037-2200) at its front edge. The ESP32-S3 reads the mic directly over the USB data lines used as GPIOs:
  D-  (GPIO19 on the S3)  -> mic CLK
  D+  (GPIO20 on the S3)  -> mic DATA
  VBUS 5 V -> XC6206P332MR LDO -> 3.3 V for the mic; SEL via solder jumper JP1.

Coordinates: mm, x across the board (0 = centre), y towards the back. The board's front
edge (where the plug sticks out) is at y = FRONT.
Run with KiCad 7's Python (pcbnew).
"""
import math
import os
import sys

import pcbnew
from pcbnew import FromMM, VECTOR2I

OUT = sys.argv[1] if len(sys.argv) > 1 else "IM73D122_USB_A.kicad_pcb"
X0, Y0 = 100.0, 80.0          # where the board sits on the KiCad page
FPLIB = "/usr/share/kicad/footprints"

# ---------------------------------------------------------------- dimensions
FRONT = 4.3                   # board front edge = the connector's "PCB edge" line
BODY_W = 14.0
BOARD_L = 25.0                # back edge (board is BOARD_L - FRONT = 20.7 mm long)
FRONT_R = 0.5                 # front corner radius
BACK_R = 1.5                  # back corner radius
USB_FP = "USB_A_Molex_48037-2200_Horizontal"
USB_PAD_Y = FRONT + 5.35      # centre of the connector's signal pads (2 mm long, end at FRONT + 6.35)
CONTACTS = [(1, "VBUS", -3.5), (2, "PDM_CLK", -1.0), (3, "PDM_DAT", 1.0), (4, "GND", 3.5)]   # D- = CLK, D+ = DATA
MIC_C = (0.0, 20.6)           # IM73D122 module centre: 15.5 mm round module on 2.5 mm headers,
MIC_D = 15.5                  # its front edge just behind the shoulder (it overhangs the back)

def P(x, y):
    return VECTOR2I(FromMM(X0 + x), FromMM(Y0 + y))

board = pcbnew.NewBoard(OUT)
ds = board.GetDesignSettings()
ds.SetBoardThickness(FromMM(1.6))
ds.m_CopperEdgeClearance = FromMM(0.3)
ds.m_MinClearance = FromMM(0.2)
ds.m_TrackMinWidth = FromMM(0.2)
ds.m_ViasMinSize = FromMM(0.6)
ds.m_MinThroughDrill = FromMM(0.3)
ds.m_HoleClearance = FromMM(0.25)
ds.m_SilkClearance = FromMM(0.0)
nc = ds.m_NetSettings.m_DefaultNetClass
nc.SetClearance(FromMM(0.2))
nc.SetTrackWidth(FromMM(0.3))
nc.SetViaDiameter(FromMM(0.6))
nc.SetViaDrill(FromMM(0.3))

nets = {}
for name in ("GND", "VBUS", "+3V3", "PDM_CLK", "PDM_CLK_MIC", "PDM_DAT", "PDM_DAT_MIC", "MIC_SEL"):
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n

# ---------------------------------------------------------------- outline
def edge_line(a, b):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(FromMM(0.05))
    s.SetStart(P(*a))
    s.SetEnd(P(*b))
    board.Add(s)

def edge_arc(center, start, angle_deg):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_ARC)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(FromMM(0.05))
    s.SetCenter(P(*center))
    s.SetStart(P(*start))
    s.SetArcAngleAndEnd(pcbnew.EDA_ANGLE(angle_deg, pcbnew.DEGREES_T), True)
    board.Add(s)

bw, L, r, fr = BODY_W / 2, BOARD_L, BACK_R, FRONT_R
edge_line((-bw + fr, FRONT), (bw - fr, FRONT))
edge_arc((bw - fr, FRONT + fr), (bw - fr, FRONT), 90)        # front right corner
edge_line((bw, FRONT + fr), (bw, L - r))
edge_arc((bw - r, L - r), (bw, L - r), 90)                   # back right corner
edge_line((bw - r, L), (-bw + r, L))
edge_arc((-bw + r, L - r), (-bw + r, L), 90)                 # back left corner
edge_line((-bw, L - r), (-bw, FRONT + fr))
edge_arc((-bw + fr, FRONT + fr), (-bw, FRONT + fr), 90)      # front left corner

# ---------------------------------------------------------------- footprints
def add_text(fp_or_board, text, x, y, layer, size=1.0, thick=0.15, mirror=False, board_level=True):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(P(x, y))
    t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(thick))
    t.SetMirrored(mirror)
    board.Add(t)
    return t

def place(fp, ref, value, x, y, rot=0):
    fp.SetReference(ref)
    fp.SetValue(value)
    fp.SetPosition(P(x, y))
    fp.SetOrientationDegrees(rot)
    fp.Reference().SetVisible(False)
    fp.Value().SetVisible(False)
    board.Add(fp)
    return fp

# USB-A plug J1, Molex 48037-2200 (SMT, right angle, for 1.6 mm boards): its "PCB edge" line
# sits on the board's front edge and the plug sticks out ~15 mm in front.
usb = pcbnew.FootprintLoad(f"{FPLIB}/Connector_USB.pretty", USB_FP)
usb.SetFPID(pcbnew.LIB_ID("Connector_USB", USB_FP))
place(usb, "J1", "Molex 48037-2200", 0.0, FRONT - 5.625, 90)
for pd in usb.Pads():
    if pd.GetNumber() in ("1", "2", "3", "4"):
        pd.SetNet(nets[{1: "VBUS", 2: "PDM_CLK", 3: "PDM_DAT", 4: "GND"}[int(pd.GetNumber())]])
    elif pd.GetNumber() == "5":
        pd.SetNet(nets["GND"])                       # shell
jpos = {pd.GetNumber(): (round(pcbnew.ToMM(pd.GetPosition().x) - X0, 3), round(pcbnew.ToMM(pd.GetPosition().y) - Y0, 3)) for pd in usb.Pads() if pd.GetNumber() in "1234" and pd.GetNumber()}
print("J1 pads", jpos)
for pin_, net_, x_ in CONTACTS:
    assert abs(jpos[str(pin_)][0] - x_) < 0.01 and abs(jpos[str(pin_)][1] - USB_PAD_Y) < 0.01, jpos

# IM73D122 module: 2 x 3 pins, 2.00 mm pitch, columns 8.00 mm apart (Dan's adapter footprint)
mic = pcbnew.FOOTPRINT(board)
mic.SetFPID(pcbnew.LIB_ID("im73d122_usb", "IM73D122_Module_2x3_P2.00mm_8.00mm"))
mic.SetAttributes(pcbnew.FP_THROUGH_HOLE)
place(mic, "U2", "IM73D122 module", *MIC_C)
mic_pins = {  # pin: (dx, dy, net)
    1: (-4.0, -2.0, "+3V3"), 2: (-4.0, 0.0, "GND"), 3: (-4.0, 2.0, None),
    4: (4.0, -2.0, "MIC_SEL"), # SEL -> JP1 (GND = left channel as made, 3V3 = right)
    5: (4.0, 0.0, "PDM_CLK_MIC"), 6: (4.0, 2.0, "PDM_DAT_MIC"),   # CLK via R2, DATA via R1
}
for num, (dx, dy, net) in mic_pins.items():
    pad = pcbnew.PAD(mic)
    pad.SetNumber(str(num))
    pad.SetAttribute(pcbnew.PAD_ATTRIB_PTH)
    pad.SetShape(pcbnew.PAD_SHAPE_RECT if num == 1 else pcbnew.PAD_SHAPE_CIRCLE)
    pad.SetSize(VECTOR2I(FromMM(1.4), FromMM(1.4)))
    pad.SetDrillSize(VECTOR2I(FromMM(0.8), FromMM(0.8)))
    pad.SetLayerSet(pad.PTHMask())
    mic.Add(pad)
    pad.SetPos0(VECTOR2I(FromMM(dx), FromMM(dy)))
    pad.SetDrawCoord()
    if net:
        pad.SetNet(nets[net])
# pin 1 marker
dot = pcbnew.FP_SHAPE(mic, pcbnew.SHAPE_T_CIRCLE)
dot.SetLayer(pcbnew.F_SilkS)
dot.SetWidth(FromMM(0.15))
dot.SetStart0(VECTOR2I(FromMM(-2.6), FromMM(-2.8)))
dot.SetEnd0(VECTOR2I(FromMM(-2.6 + 0.35), FromMM(-2.8)))
dot.SetDrawCoord()
mic.Add(dot)

# Module outline (15.5 mm) on the silkscreen, only the parts that fall on the board
def silk_seg(a, b, layer=pcbnew.F_SilkS, w=0.15):
    sh = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    sh.SetLayer(layer); sh.SetWidth(FromMM(w)); sh.SetStart(P(*a)); sh.SetEnd(P(*b))
    board.Add(sh)
R = MIC_D / 2
pts = [(MIC_C[0] + R * math.cos(math.radians(a)), MIC_C[1] + R * math.sin(math.radians(a))) for a in range(0, 361, 3)]
inside = lambda q: abs(q[0]) <= BODY_W / 2 - 0.35 and FRONT + 0.3 <= q[1] <= BOARD_L - 0.35
runs, cur = [], []
for q in pts:
    if inside(q): cur.append(q)
    else:
        if len(cur) > 1: runs.append(cur)
        cur = []
if len(cur) > 1: runs.append(cur)
for run in runs:
    if math.dist(run[0], run[-1]) < 1.0: continue
    for a, b in zip(run, run[1:]): silk_seg(a, b)

# Regulator, capacitors and R1: all on the BACK. U1/C1/C2 sit between the module's two
# pin columns, R1 outside the right column, level with C1, in the DATA line.
def place_back(fp, ref, value, x, y, rot=0):
    place(fp, ref, value, x, y)
    fp.Flip(fp.GetPosition(), False)
    fp.SetOrientationDegrees(rot)
    return fp
def pads_xy(fp):
    return {p.GetNumber(): (pcbnew.ToMM(p.GetPosition().x) - X0, pcbnew.ToMM(p.GetPosition().y) - Y0) for p in fp.Pads()}
def padnet(fp, num, net):
    for p in fp.Pads():
        if p.GetNumber() == str(num):
            p.SetNet(nets[net]); return
    raise KeyError(num)
def padpos(fp, num):
    return pads_xy(fp)[str(num)]

CAP = "C_0805_2012Metric_Pad1.18x1.45mm_HandSolder"
RES = "R_0805_2012Metric_Pad1.20x1.40mm_HandSolder"
C1 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Capacitor_SMD.pretty", CAP), "C1", "1uF", -4.3, 15.3)
U1_ROT = int(os.environ.get("U1_ROT", "90"))
U1 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Package_TO_SOT_SMD.pretty", "SOT-89-3"), "U1", "XC6206P332PR", 0.0, 18.55, U1_ROT)
C2 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Capacitor_SMD.pretty", CAP), "C2", "1uF", 0.0, 22.4, 180)
R1 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Resistor_SMD.pretty", RES), "R1", "0R", 5.9, 14.4, 90)
R2 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Resistor_SMD.pretty", RES), "R2", "0R", 2.7, 14.4, 90)
JPF = "SolderJumper-3_P1.3mm_Bridged12_RoundedPad1.0x1.5mm"
JP1 = place_back(pcbnew.FootprintLoad(f"{FPLIB}/Jumper.pretty", JPF), "JP1", "SEL", 5.9, 19.6, -90)
JP1.SetFPID(pcbnew.LIB_ID("Jumper", JPF))
JP1.SetAttributes(JP1.GetAttributes() | pcbnew.FP_EXCLUDE_FROM_BOM)
for it in list(JP1.GraphicalItems()):          # drop its outline: the L / R labels mark it
    if it.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS):
        JP1.Remove(it)
U1.SetFPID(pcbnew.LIB_ID("Package_TO_SOT_SMD", "SOT-89-3"))
# trim U1's silkscreen outline where it runs closer than 0.25 mm to a pad (JLCPCB silk-to-pad check)
for it in list(U1.GraphicalItems()):
    if it.GetLayer() == pcbnew.B_SilkS and it.GetClass() != "FP_TEXT":
        U1.Remove(it)   # SOT-89 outline would sit under the sideways U1 label
for c in (C1, C2): c.SetFPID(pcbnew.LIB_ID("Capacitor_SMD", CAP))
for r in (R1, R2): r.SetFPID(pcbnew.LIB_ID("Resistor_SMD", RES))
# XC6206 SOT-89: 1 = GND, 2 = VIN (and the tab), 3 = VOUT
padnet(U1, 1, "GND"); padnet(U1, 2, "VBUS"); padnet(U1, 3, "+3V3")
def by_x(fp): return sorted(fp.Pads(), key=lambda p: p.GetPosition().x)
def by_y(fp): return sorted(fp.Pads(), key=lambda p: p.GetPosition().y)
c1l, c1r = by_x(C1); c1l.SetNet(nets["GND"]); c1r.SetNet(nets["VBUS"])   # C1 outside the 5 V track, 5 V pad towards it
c2l, c2r = by_x(C2); c2l.SetNet(nets["+3V3"]); c2r.SetNet(nets["GND"])
r1t, r1b = by_y(R1); r1t.SetNet(nets["PDM_DAT"]); r1b.SetNet(nets["PDM_DAT_MIC"])
r2t, r2b = by_y(R2); r2t.SetNet(nets["PDM_CLK"]); r2b.SetNet(nets["PDM_CLK_MIC"])
xy = lambda p: (pcbnew.ToMM(p.GetPosition().x) - X0, pcbnew.ToMM(p.GetPosition().y) - Y0)
u1 = pads_xy(U1)
print("U1", u1, "C1", xy(c1l), xy(c1r), "C2", xy(c2l), xy(c2r), "R1", xy(r1t), xy(r1b))
assert u1["2"][1] < u1["1"][1] and u1["3"][0] < 0 < u1["1"][0], "U1 pin layout not as routed"   # tab (IN) at the top, OUT bottom-left, GND bottom-right

# ---------------------------------------------------------------- routing
def track(points, net, width, layer=pcbnew.F_Cu):
    for a, b in zip(points, points[1:]):
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(P(*a)); t.SetEnd(P(*b))
        t.SetWidth(FromMM(width)); t.SetLayer(layer); t.SetNet(nets[net])
        board.Add(t)

def via(x, y, net):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(P(x, y))
    v.SetWidth(FromMM(0.6)); v.SetDrill(FromMM(0.3))
    v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
    v.SetNet(nets[net])
    board.Add(v)

Bk = pcbnew.B_Cu
pin = lambda n: (MIC_C[0] + mic_pins[n][0], MIC_C[1] + mic_pins[n][1])
# VBUS: J1 pin 1 -> via -> back -> C1 (left pad) and U1 input
track([(-3.5, USB_PAD_Y), (-3.5, 11.3)], "VBUS", 0.5)
via(-3.5, 11.3, "VBUS")
track([(-3.5, 11.3), (-2.2, 12.6), (-2.2, xy(c1r)[1]), (-0.3, xy(c1r)[1]), (-0.3, 17.0)], "VBUS", 0.6, Bk)   # into the top of the tab
track([(-2.2, xy(c1r)[1]), xy(c1r)], "VBUS", 0.6, Bk)
# 3V3: U1 out -> C2 (right pad) -> round C2 -> module pin 1 (back)
track([u1["3"], (u1["3"][0], xy(c2l)[1]), xy(c2l)], "+3V3", 0.4, Bk)
track([u1["1"], (u1["1"][0], xy(c2r)[1]), xy(c2r)], "GND", 0.4, Bk)
# U1 output straight across to module pin 1 (3V3)
track([u1["3"], (-2.4, 19.5), pin(1)], "+3V3", 0.4, Bk)
# J1 GND pin -> top fill; stitching vias
track([(3.5, USB_PAD_Y), (3.5, 11.3)], "GND", 0.6)
# (none near the panel's break-off tabs: sides y 9.2-11.6, back edge |x| 1.5-5.5)
for x, y in [(3.5, 11.3), (-5.0, 11.5), (3.6, 17.0), (-2.7, 22.3), (2.2, 22.8),
             (-6.2, 13.8), (-6.2, 22.6), (-0.6, 14.0)]:
    via(x, y, "GND")
# CLK (D-): via to the back, R2, then down between the regulator parts and the right pin column
track([(-1.0, USB_PAD_Y), (-1.0, 11.3)], "PDM_CLK", 0.3)
via(-1.0, 11.3, "PDM_CLK")
track([(-1.0, 11.3), (-1.0, 12.3), (0.5, xy(r2t)[1]), xy(r2t)], "PDM_CLK", 0.3, Bk)   # into the side of R2's pad
track([xy(r2b), (xy(r2b)[0], pin(5)[1] - 0.6), (xy(r2b)[0] + 0.6, pin(5)[1]), pin(5)], "PDM_CLK_MIC", 0.3, Bk)   # straight down
# DATA (D+): via to the back, down outside the right pin column to R1, R1 -> module pin 6
track([(1.0, USB_PAD_Y), (1.0, 11.3)], "PDM_DAT", 0.3)
via(1.0, 11.3, "PDM_DAT")
track([(1.0, 11.3), (1.9, 12.2), (4.9, 12.2), (xy(r1t)[0], 13.2), xy(r1t)], "PDM_DAT", 0.3, Bk)
# after R1, DATA hops to the top for the run down to module pin 6 (frees the back for JP1)
track([xy(r1b), (xy(r1b)[0], 16.3), (4.6, 16.9)], "PDM_DAT_MIC", 0.3, Bk)
via(4.6, 16.9, "PDM_DAT_MIC")
track([(4.6, 16.9), (5.9, 18.2), (5.9, pin(6)[1] - 0.7), (5.2, pin(6)[1]), pin(6)], "PDM_DAT_MIC", 0.3)
# JP1: pad 1 GND (bridged to pad 2 as made), pad 2 SEL, pad 3 3V3
jp = {p.GetNumber(): p for p in JP1.Pads()}
jp["1"].SetNet(nets["GND"]); jp["2"].SetNet(nets["MIC_SEL"]); jp["3"].SetNet(nets["+3V3"])
assert xy(jp["1"])[1] < xy(jp["2"])[1] < xy(jp["3"])[1], [xy(jp[k]) for k in "123"]
track([xy(jp["2"]), (5.0, xy(jp["2"])[1]), pin(4)], "MIC_SEL", 0.3, Bk)
track([xy(jp["1"]), (xy(jp["1"])[0], 17.5)], "GND", 0.3, Bk)   # GND pad into the fill (fill kept off the jumper)
track([xy(c2l), (xy(c2l)[0], 23.8), (5.0, 23.8), (5.9, 22.9), xy(jp["3"])], "+3V3", 0.4, Bk)

# ---------------------------------------------------------------- ground fills
def zone(layer, poly, net="GND"):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    z.SetNet(nets[net])
    z.SetLocalClearance(FromMM(0.25))
    z.SetMinThickness(FromMM(0.25))
    z.SetThermalReliefGap(FromMM(0.3))
    z.SetThermalReliefSpokeWidth(FromMM(0.4))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
    ol = z.Outline()
    ol.NewOutline()
    for x, y in poly:
        ol.Append(FromMM(X0 + x), FromMM(Y0 + y))
    board.Add(z)
    return z

zone(pcbnew.F_Cu, [(-bw, FRONT), (bw, FRONT), (bw, L), (-bw, L)])
zone(pcbnew.B_Cu, [(-bw, FRONT), (bw, FRONT), (bw, L), (-bw, L)])
# keep the ground fill off the solder jumper (its GND-SEL bridge is part of the footprint)
ka = pcbnew.ZONE(board)
ka.SetIsRuleArea(True); ka.SetLayer(pcbnew.B_Cu)
ka.SetDoNotAllowCopperPour(True); ka.SetDoNotAllowTracks(False); ka.SetDoNotAllowVias(False)
ka.SetDoNotAllowPads(False); ka.SetDoNotAllowFootprints(False)
ol = ka.Outline(); ol.NewOutline()
for x, y in [(5.05, 17.7), (6.85, 17.7), (6.85, 21.5), (5.05, 21.5)]:
    ol.Append(FromMM(X0 + x), FromMM(Y0 + y))
board.Add(ka)
# keep the ground fill clear of the panel's mouse-bite holes (break-off tabs, see make_panel.sh)
TAB_KEEPOUTS = [[(6.1, 7.6), (7.5, 7.6), (7.5, 13.2), (6.1, 13.2)],          # sides, y 10.4
                [(-7.5, 7.6), (-6.1, 7.6), (-6.1, 13.2), (-7.5, 13.2)],
                [(0.7, 24.1), (6.3, 24.1), (6.3, 25.5), (0.7, 25.5)],          # back edge, x +-3.5
                [(-6.3, 24.1), (-0.7, 24.1), (-0.7, 25.5), (-6.3, 25.5)],
                [(0.7, 3.5), (6.3, 3.5), (6.3, 5.2), (0.7, 5.2)],              # front edge, x +-3.5
                [(-6.3, 3.5), (-0.7, 3.5), (-0.7, 5.2), (-6.3, 5.2)]]
LS2 = pcbnew.LSET(); LS2.AddLayer(pcbnew.F_Cu); LS2.AddLayer(pcbnew.B_Cu)
for poly in TAB_KEEPOUTS:
    k = pcbnew.ZONE(board)
    k.SetIsRuleArea(True); k.SetLayerSet(LS2)
    k.SetDoNotAllowCopperPour(True); k.SetDoNotAllowTracks(False); k.SetDoNotAllowVias(False)
    k.SetDoNotAllowPads(False); k.SetDoNotAllowFootprints(False)
    o = k.Outline(); o.NewOutline()
    for x, y in poly:
        o.Append(FromMM(X0 + x), FromMM(Y0 + y))
    board.Add(k)
pcbnew.ZONE_FILLER(board).Fill(board.Zones())

# ---------------------------------------------------------------- silkscreen
F, B = pcbnew.F_SilkS, pcbnew.B_SilkS
add_text(board, "U2", 0.0, 17.5, F, size=1.0)
add_text(board, "J1", 0.0, 12.0, F, size=1.0)        # centred between the D-/D+ vias and the mic outline
add_text(board, "Port", 0.0, MIC_C[1] - 0.7, F, size=1.0)
add_text(board, "up", 0.0, MIC_C[1] + 0.7, F, size=1.0)
# back: title between the connector's shell tabs and the contact vias
add_text(board, "IM73D122 USB", 0.0, 9.8, B, size=1.0, mirror=True)
t = add_text(board, "v3.2", -6.0, 18.6, B, size=1.0, mirror=True); t.SetTextAngleDegrees(90)
add_text(board, "C1", -4.3, 13.75, B, size=1.0, mirror=True)
t = add_text(board, "U1", 2.5, 17.9, B, size=1.0, mirror=True); t.SetTextAngleDegrees(90)
add_text(board, "C2", 0.0, 24.0, B, size=1.0, mirror=True)
t = add_text(board, "R1", 4.3, 14.4, B, size=1.0, mirror=True); t.SetTextAngleDegrees(90)
add_text(board, "L", 5.9, 16.9, B, size=1.0, mirror=True)
add_text(board, "R", 5.9, 22.55, B, size=1.0, mirror=True)
t = add_text(board, "R2", 1.15, 14.4, B, size=1.0, mirror=True); t.SetTextAngleDegrees(90)

# Project footprint library with the two custom footprints, and its library table
libdir = os.path.join(os.path.dirname(os.path.abspath(OUT)), "im73d122_usb.pretty")
os.makedirs(libdir, exist_ok=True)
for fp in (mic,):
    copy = pcbnew.FOOTPRINT(fp)
    copy.SetPosition(VECTOR2I(0, 0))
    copy.SetOrientationDegrees(0)
    for p in copy.Pads():
        p.SetNetCode(0)
    pcbnew.FootprintSave(libdir, copy)
with open(os.path.join(os.path.dirname(os.path.abspath(OUT)), "fp-lib-table"), "w") as f:
    f.write('(fp_lib_table\n  (version 7)\n  (lib (name "im73d122_usb")(type "KiCad")(uri "${KIPRJMOD}/im73d122_usb.pretty")(options "")(descr "IM73D122 USB-A mic board footprints"))\n)\n')
pcbnew.SaveBoard(OUT, board)
print("saved", OUT)
