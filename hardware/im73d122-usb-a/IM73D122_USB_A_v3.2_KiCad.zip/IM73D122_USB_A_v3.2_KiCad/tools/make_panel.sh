#!/bin/sh
# Builds the panel: 4 rows x 6 boards (24) within 100 x 100 mm, no rails. Rows come in
# back-to-back pairs joined by tabs on the back edges; the two pairs are joined by tabs on their
# front (plug) edges, where the break-off nubs end up under the overhanging plug. Side tabs join
# the columns. Needs KiKit 1.6 (KiCad 7) on python3.12.
set -e
cd "$(dirname "$0")/.."
TMP=build/panel_src
rm -rf "$TMP" && mkdir -p "$TMP"
cp IM73D122_USB_A/IM73D122_USB_A.kicad_pcb IM73D122_USB_A/IM73D122_USB_A.kicad_pro "$TMP"/
/usr/bin/python3.12 - "$TMP/IM73D122_USB_A.kicad_pcb" <<'PY'
import sys, pcbnew, kikit, os
from pcbnew import FromMM, VECTOR2I
path = sys.argv[1]
b = pcbnew.LoadBoard(path)
lib = os.path.join(os.path.dirname(kikit.__file__), "resources", "kikit.pretty")
X0, Y0 = 100.0, 80.0
# Each annotation sits on this board's edge and points INTO this board (KiKit builds the tab from
# there out to the halfway line between boards). Sides: 180 = towards -x, 0 = towards +x;
# back edge: 90 = towards -y; front edge: -90 = towards +y.
tabs = [(7.0, 10.4, 180), (-7.0, 10.4, 0), (-3.5, 25.0, 90), (3.5, 25.0, 90),
        (-3.5, 4.3, -90), (3.5, 4.3, -90)]   # front edge: the nubs end up under the plug, out of the way
for i, (x, y, rot) in enumerate(tabs, 1):
    fp = pcbnew.FootprintLoad(lib, "Tab")
    fp.SetFPID(pcbnew.LIB_ID("kikit", "Tab"))
    fp.SetReference(f"KIKIT_TAB{i}")
    fp.SetPosition(VECTOR2I(FromMM(X0 + x), FromMM(Y0 + y)))
    fp.SetOrientationDegrees(rot)
    b.Add(fp)
# J1's plug overhangs the board by ~15 mm: drop its courtyard / fab / drawing outlines in the
# panel copy so KiKit keeps it (its pads are needed) and plugs facing each other don't clash.
for fp in b.GetFootprints():
    if fp.GetReference() == "J1":
        for it in list(fp.GraphicalItems()):
            if it.GetLayer() in (pcbnew.F_CrtYd, pcbnew.B_CrtYd, pcbnew.F_Fab, pcbnew.B_Fab, pcbnew.Dwgs_User):
                fp.Remove(it)
pcbnew.SaveBoard(path, b)
PY
mkdir -p IM73D122_USB_A_Panel
rm -f IM73D122_USB_A_Panel/*
/usr/bin/python3.12 -m kikit.ui panelize \
  --layout 'grid; rows: 4; cols: 6; hspace: 2mm; vspace: 2mm; alternation: rows' \
  --tabs 'annotation' \
  --cuts 'mousebites; drill: 0.5mm; spacing: 0.8mm; offset: -0.2mm; prolong: 0.5mm' \
  --framing 'none' --post 'millradius: 0.5mm' \
  --source 'auto; tolerance: 16mm' \
  "$TMP/IM73D122_USB_A.kicad_pcb" IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb
echo "panel done"
