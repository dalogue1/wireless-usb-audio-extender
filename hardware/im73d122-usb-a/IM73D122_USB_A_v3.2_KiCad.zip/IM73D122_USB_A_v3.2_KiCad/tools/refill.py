#!/usr/bin/env python3
"""Reloads a board so all design rules are active, refills every zone and saves it."""
import sys
import pcbnew
b = pcbnew.LoadBoard(sys.argv[1])
b.BuildConnectivity()
f = pcbnew.ZONE_FILLER(b)
f.Fill(b.Zones())
pcbnew.SaveBoard(sys.argv[1], b)
pcbnew.WriteDRCReport(b, sys.argv[2] if len(sys.argv) > 2 else "/tmp/drc.rpt", pcbnew.EDA_UNITS_MILLIMETRES, True)
print("refilled", sys.argv[1])
