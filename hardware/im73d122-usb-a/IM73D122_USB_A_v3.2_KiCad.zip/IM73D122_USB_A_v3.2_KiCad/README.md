# IM73D122 USB-A mic board v3.2

A small PCB with a soldered-on USB-A plug (J1, Molex 48037-2200). It carries an IM73D122 PDM microphone module and a 3.3 V regulator. Plugged into the USB-A socket of an OTG adapter on a XIAO ESP32-S3, the S3 reads the mic **directly over the USB data lines used as ordinary GPIOs**. This is not USB: no USB chip, no protocol.

| J1 pin | Signal | ESP32-S3 | Mic |
|---|---|---|---|
| 1 VBUS | 5 V | (from the adapter) | → XC6206 → 3.3 V |
| 2 D− | PDM clock | GPIO19 | CLK (through R2) |
| 3 D+ | PDM data | GPIO20 | DATA (through R1) |
| 4 GND | ground | GND | GND |

SEL goes to solder jumper JP1 on the back: **bridged to GND (left channel) as made**. To switch the mic to the right channel, cut the thin bridge between the L pad and the middle pad, then solder-bridge the middle pad to the R pad (3.3 V). With one mic per S3 either setting works, as long as the firmware reads (or auto-detects) the matching channel.

| Top | Back |
|---|---|
| ![top](images/board_top.png) | ![back](images/board_bottom.png) |

## Board

* 14.0 × 20.7 mm, standard **1.6 mm** thickness, any surface finish (HASL is fine), 2 layers. The plug sticks out about 15 mm in front of the board.
* J1: Molex 48037-2200 surface-mount USB-A plug, made for 1.6 mm boards. Its four signal pads are on the top, behind the plug body; its two shell tabs go through the board and are soldered on the back (ground); two plastic pegs locate it. The connector's own contacts handle the orientation and make power and ground connect first.
* IM73D122 module footprint: 2 × 3 pins, 2.00 mm pitch, rows 8.00 mm apart, 1.4 mm pads with 0.8 mm holes (the same as your IM73D122 adapter board). Pin 1 (square pad) = 3V3.
* The 15.5 mm module sits on its 2.5 mm plastic headers on the top, its front edge about 4.8 mm behind the plug body. It overhangs the sides by 0.75 mm and the back by about 3.3 mm, like on the IM73D122 adapter board.
* All the small parts are on the **back**: U1 and C2 between the module's two pin columns, C1 above the pin-1 column (outside the 5 V track), R1 and R2 side by side in the DATA and CLK lines. The top carries the plug and the module.
* Copper: 0.3 mm signal tracks, 0.25 mm minimum gap, 0.3 mm from the board edge; ground fills on both sides.
* R1 on the back, in the DATA line about 8 mm from the mic's DATA pin (electrically the same as right at the pin at 3 MHz), is a series resistor on the data line: 0 Ω normally, 33–100 Ω to tame ringing on a long passive USB extension.
* Checked: KiCad DRC (0 errors, 0 unconnected; the only warnings are about library names in the checking setup), plus an independent check of the Gerbers: J1 pin order, every net connected, no copper within 0.3 mm of the edge.

## Parts (hand-solderable)

| Ref | Part | Package | Notes |
|---|---|---|---|
| J1 | Molex 48037-2200 USB-A plug | SMT + 2 shell tabs, top | DigiKey WM3983CT-ND, also Mouser, RS (800-6772), Farnell. Not interchangeable with other USB-A plugs: pad and tab positions differ |
| U1 | XC6206P332PR 3.3 V LDO | SOT-89, back | pins 1 GND, 2 IN (and the tab), 3 OUT. LCSC C545581 (UMW) or C41322 (Torex), DigiKey 4518-XC6206P332PRCT-ND. Check a copy's datasheet pinout first |
| C1, C2 | 1 µF ceramic, X5R/X7R, ≥ 10 V | 0805, back | C1 = input, C2 = output |
| R1 | 0 Ω (standard) or 33–100 Ω | 0805, back | series resistor in the DATA line. **Must be fitted**: without it the mic is disconnected. Use 33–100 Ω only if a long USB extension gives clicks or noise |
| JP1 | solder jumper (no part) | back | channel select: L (as made) or R |
| R2 | 0 Ω (standard) or 33–100 Ω | 0805, back | series resistor in the CLK line. **Must be fitted**. 33–100 Ω limits overshoot into the mic's clock input on a long cable |
| U2 | IM73D122 module (15.5 mm) | 2 × 3 pins on 2.5 mm headers, top | mic port up |

Solder the five parts on the back first, then J1 (signal pads on the top, shell tabs from the back), then the module on the top.

## Ordering (JLCPCB)

Upload `IM73D122_USB_A_gerbers.zip` (single board) or `IM73D122_USB_A_panel_gerbers.zip` (both in the Gerbers download) (24 boards, 6 × 4, 94.1 × 88.9 mm, inside the 100 × 100 mm base-price size). Standard options: 1.6 mm, HASL. Mark the panel as a "panel by customer" with 24 boards.

Panel layout, no rails: rows come in back-to-back pairs joined by break-off tabs on the back edges; the two pairs are joined by tabs on their front (plug) edges, where the small break-off nubs end up under the overhanging plug and touch nothing. Side tabs join the columns. The panel's top and bottom edges are plug edges with no tabs.

## Use

* The OTG adapter must be a plain wired adapter. One with a hub chip inside won't pass the signals through.
* The S3's USB port is then no longer USB: to flash new firmware, unplug the mic board and hold BOOT while plugging in the XIAO.

## Firmware notes (S3 side, not included here)

* Release GPIO19/20 from the USB-Serial-JTAG peripheral (USB Mode "Hardware CDC and JTAG" with CDC On Boot disabled, then reconfigure the pins) and **turn off its D+ pull-up**, which otherwise sits on the data line.
* I2S PDM receive: CLK = GPIO19, DATA = GPIO20, 3.072 MHz clock (48 kHz).
* Set GPIO19 (CLK) to the weakest drive strength (`gpio_set_drive_capability(GPIO_NUM_19, GPIO_DRIVE_CAP_0)`): softer clock edges, less ringing and less crosstalk into DATA on a cable. It is the clock-side counterpart of R1.
* Pick the mic's slot by signal variation, not raw energy: an idle slot held high by a pull-up looks loud by energy alone.

## Extension cables

A short passive USB-A extension (up to about 1 m) should work with R1 = 0 Ω. Longer runs are untested: D+ and D− are a twisted pair, so the 3.072 MHz clock couples into the data wire, and the cable loads the mic's output. Errors show up as clicks or noise bursts, not duller sound. Try R1 and R2 = 33–100 Ω if that happens. Active (repeater) extensions won't work.

## Changes

* v3.2: U1 changed from SOT-23 to SOT-89 (XC6206P332PR), easier to hand-solder. Board size unchanged. U1 and C2 moved down slightly, C1 up 0.3 mm, 5 V now feeds the tab from above, U1 label sideways beside it, U1 outline dropped.

* v3.1 (J1 label): "J1" added on the top silkscreen beside the USB plug, matching the docs.
* v3.1 (silk fix): all silkscreen at least 0.18 mm from pads (JLCPCB check). R1 and R2 moved up 0.4 mm to make room for the L label above JP1; R moved down; U1 and C1 labels nudged; U1's silk outline dropped where it crowded the pads.
* v3.1 (panel fix): every side bridge now has mouse bites on both ends (the first and last columns were missing one row, and stray holes sat on the panel's outer edge). All mouse-bite holes now sit on the bridges, just outside the board edges, instead of 0.2 mm into the boards. Board unchanged.
* v3.1: fixes from JLCPCB review. JP1 moved 0.15 mm toward the edge (gap to the module pins 0.3 → 0.45 mm). The side break-off tabs moved forward, away from JP1, to sit beside the connector. The ground fill is kept clear of every mouse-bite hole (it overlapped them by 0.15 mm; now ≥0.45 mm clearance).
* v3.0 (panel update): 24 boards per panel (was 10), no rails; board unchanged.
* v3.0: the edge-finger plug (needed a 2.0 mm board and a hard-wearing finish) replaced by a solder-on Molex 48037-2200 USB-A plug on a standard 1.6 mm board; board 14 × 20.7 mm; everything behind the contacts unchanged.
* v2.9: R2 label turned sideways to match R1.
* v2.8: SEL now goes through 3-pad solder jumper JP1 (back, beside the right pin column), bridged to GND (left channel) as made; DATA to the mic runs on the top after R1 to make room.
* v2.7: C2 moved 0.7 mm closer to U1.
* v2.6: 3.3 V runs straight from U1's output to the module's pin 1 (no longer round the outside of the pin column).
* v2.5: R2 moved 0.3 mm inward so the CLK track runs straight down to the mic; the incoming CLK track enters the side of R2's pad.
* v2.4: U1 and C2 labels placed horizontally under their parts.
* v2.3: U1 moved 2 mm towards the contacts, leaving more room between U1 and C2.
* v2.2: U1 turned 90° (input towards the contacts, output towards C2) and C2 turned 180°, so the 5 V and 3.3 V paths are short and direct.
* v2.1: C1 moved to the outside of the 5 V track, above the pin-1 column; R2 level with R1.
* v2.0: R2, a 0805 series resistor in the CLK line (back side); CLK now runs on the back, so the top carries only the module.
* v1.9: 3.3 V track now runs round the outside of the left pin column; the 5 V track between the columns is wider (0.6 mm) with more clearance.
* v1.8: ground via moved off the C1 label on the back.
* v1.7: vias behind the contacts moved 1.5 mm back, so the note on the back has a clear gap under the title.
* v1.6: R1 moved up the DATA line to C1's level, away from the module's pin joints (easier to solder).
* v1.5: "Contacts face socket tongue" note moved up on the back, just under the title.
* v1.4: contact labels (5V, D−, D+, GND) moved to the front, behind each contact; the "Contacts face socket tongue" note stays on the back.
* v1.3: all small parts moved to the back (U1, C1, C2 between the module's pin columns); module moved forward for its real 15.5 mm size; board shortened from 29.5 to 25.0 mm; CLK now runs on the top.
* v1.2: part labels on the top silkscreen (U1, C1, C2, U2; R1 on the back).
* v1.1: R1, a 0805 series resistor on DATA at the mic (back side). Board size unchanged.
* v1.0: first version.

## Files

```
IM73D122_USB_A/         KiCad 7 board (+ project library im73d122_usb.pretty for the module footprint, fp-lib-table)
IM73D122_USB_A_Panel/   KiCad 7 panel (KiKit)
images/                 previews
tools/                  scripts that generate everything (build.sh runs them all: KiCad 7, KiKit 1.6)
```

The JLCPCB-ready Gerber + drill zips (single board and panel) are a separate download.
