#!/bin/sh
# Rebuilds everything: board -> zone refill + DRC -> adapter -> combined panel -> Gerbers/drill zips.
# Needs KiCad 7 (pcbnew Python + kicad-cli) and KiKit 1.6 on python3.12.
set -e
cd "$(dirname "$0")/.."
PY=/usr/bin/python3.12
mkdir -p build IM73D122_USB_A IM73D122_USB_A_Panel adapter
# 1. USB board
$PY tools/make_board.py IM73D122_USB_A/IM73D122_USB_A.kicad_pcb > /dev/null
$PY tools/refill.py IM73D122_USB_A/IM73D122_USB_A.kicad_pcb build/drc_board.txt
# 2. one IM73D122 adapter (same design as its own panel)
$PY tools/make_adapter.py > /dev/null
# 3. panel: 12 USB boards + 12 adapters
$PY tools/make_combo_panel.py > /dev/null
$PY - <<'PYEOF'
import pcbnew
b = pcbnew.LoadBoard("IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb")
pcbnew.WriteDRCReport(b, "build/drc_panel.txt", pcbnew.EDA_UNITS_MILLIMETRES, True)
PYEOF
# 4. Gerbers + drill
export_set() { # pcb name
  out=build/gerbers_$2
  rm -rf "./$out" && mkdir -p "$out"
  kicad-cli pcb export gerbers -o "$out/" --subtract-soldermask \
    -l F.Cu,B.Cu,F.Mask,B.Mask,F.Silkscreen,B.Silkscreen,Edge.Cuts "$1" > /dev/null
  kicad-cli pcb export drill -o "$out/" --format excellon --excellon-separate-th \
    --excellon-units mm "$1" > /dev/null
  (cd "$out" && rm -f "../$2_gerbers.zip" && zip -q "../$2_gerbers.zip" *)
}
export_set IM73D122_USB_A/IM73D122_USB_A.kicad_pcb IM73D122_USB_A
export_set IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb IM73D122_USB_A_panel
mkdir -p gerbers && cp build/IM73D122_USB_A_gerbers.zip build/IM73D122_USB_A_panel_gerbers.zip gerbers/
echo "built: gerbers/IM73D122_USB_A_gerbers.zip gerbers/IM73D122_USB_A_panel_gerbers.zip"
grep -E "Found" build/drc_board.txt build/drc_panel.txt
