#!/usr/bin/env python3
"""Builds IM73D122_USB_A.kicad_pcb (v3.3): a small PCB with a soldered-on USB-A plug (Molex
48037-2200) at its front edge and a 1 x 5 right-angle 0.1" header (J2) at its back edge. The mic
board (Dan's IM73D122 adapter, or an Adafruit PDM breakout: same size and pin order 3V GND SEL
CLK DAT) stands upright on J2 at 90 degrees, pin row at its bottom, mic facing out of the back of the
board. Seen from the mic's front it reads 3V GND SEL CLK DAT left to right, as J2's labels do from behind
(in board coordinates 3V is at -x). The ESP32-S3 reads the mic directly over the USB data lines used as GPIOs:
  D-  (GPIO19 on the S3)  -> mic CLK
  D+  (GPIO20 on the S3)  -> mic DATA
  VBUS 5 V -> XC6206P332MR LDO -> 3.3 V for the mic; SEL via solder jumper JP1.

Coordinates: mm, x across the board (0 = centre), y towards the back. The board's front
edge (where the plug sticks out) is at y = FRONT.
Run with KiCad 7's Python (pcbnew).
"""
import math
import os
import sys

import pcbnew
from pcbnew import FromMM, VECTOR2I

OUT = sys.argv[1] if len(sys.argv) > 1 else "IM73D122_USB_A.kicad_pcb"
X0, Y0 = 100.0, 80.0          # where the board sits on the KiCad page
FPLIB = "/usr/share/kicad/footprints"

# ---------------------------------------------------------------- dimensions
FRONT = 4.3                   # board front edge = the connector's "PCB edge" line
BODY_W = 14.0
HDR_Y = 18.76                 # J2 pad row: its body (1.5-4.04 mm behind the row) ends exactly at the back edge
BOARD_L = HDR_Y + 4.04        # back edge = J2 body face (board is BOARD_L - FRONT = 18.5 mm long)
HDR = {"+3V3": -5.08, "GND": -2.54, "MIC_SEL": 0.0, "PDM_CLK_MIC": 2.54, "PDM_DAT_MIC": 5.08}
FRONT_R = 0.5                 # front corner radius
BACK_R = 1.5                  # back corner radius
USB_FP = "USB_A_Molex_48037-2200_Horizontal"
USB_PAD_Y = FRONT + 5.35      # centre of the connector's signal pads (2 mm long, end at FRONT + 6.35)
CONTACTS = [(1, "VBUS", -3.5), (2, "PDM_CLK", -1.0), (3, "PDM_DAT", 1.0), (4, "GND", 3.5)]   # D- = CLK, D+ = DATA

def P(x, y):
    return VECTOR2I(FromMM(X0 + x), FromMM(Y0 + y))

board = pcbnew.NewBoard(OUT)
ds = board.GetDesignSettings()
ds.SetBoardThickness(FromMM(1.6))
ds.m_CopperEdgeClearance = FromMM(0.3)
ds.m_MinClearance = FromMM(0.2)
ds.m_TrackMinWidth = FromMM(0.2)
ds.m_ViasMinSize = FromMM(0.6)
ds.m_MinThroughDrill = FromMM(0.3)
ds.m_HoleClearance = FromMM(0.25)
ds.m_SilkClearance = FromMM(0.0)
nc = ds.m_NetSettings.m_DefaultNetClass
nc.SetClearance(FromMM(0.2))
nc.SetTrackWidth(FromMM(0.3))
nc.SetViaDiameter(FromMM(0.6))
nc.SetViaDrill(FromMM(0.3))

nets = {}
for name in ("GND", "VBUS", "+3V3", "PDM_CLK", "PDM_CLK_MIC", "PDM_DAT", "PDM_DAT_MIC", "MIC_SEL"):
    n = pcbnew.NETINFO_ITEM(board, name)
    board.Add(n)
    nets[name] = n

# ---------------------------------------------------------------- outline
def edge_line(a, b):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_SEGMENT)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(FromMM(0.05))
    s.SetStart(P(*a))
    s.SetEnd(P(*b))
    board.Add(s)

def edge_arc(center, start, angle_deg):
    s = pcbnew.PCB_SHAPE(board, pcbnew.SHAPE_T_ARC)
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(FromMM(0.05))
    s.SetCenter(P(*center))
    s.SetStart(P(*start))
    s.SetArcAngleAndEnd(pcbnew.EDA_ANGLE(angle_deg, pcbnew.DEGREES_T), True)
    board.Add(s)

bw, L, r, fr = BODY_W / 2, BOARD_L, BACK_R, FRONT_R
edge_line((-bw + fr, FRONT), (bw - fr, FRONT))
edge_arc((bw - fr, FRONT + fr), (bw - fr, FRONT), 90)        # front right corner
edge_line((bw, FRONT + fr), (bw, L - r))
edge_arc((bw - r, L - r), (bw, L - r), 90)                   # back right corner
edge_line((bw - r, L), (-bw + r, L))
edge_arc((-bw + r, L - r), (-bw + r, L), 90)                 # back left corner
edge_line((-bw, L - r), (-bw, FRONT + fr))
edge_arc((-bw + fr, FRONT + fr), (-bw, FRONT + fr), 90)      # front left corner

# ---------------------------------------------------------------- footprints
def add_text(fp_or_board, text, x, y, layer, size=1.0, thick=0.15, mirror=False, board_level=True):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(P(x, y))
    t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size)))
    t.SetTextThickness(FromMM(thick))
    t.SetMirrored(mirror)
    board.Add(t)
    return t

def place(fp, ref, value, x, y, rot=0):
    fp.SetReference(ref)
    fp.SetValue(value)
    fp.SetPosition(P(x, y))
    fp.SetOrientationDegrees(rot)
    fp.Reference().SetVisible(False)
    fp.Value().SetVisible(False)
    board.Add(fp)
    return fp

# USB-A plug J1, Molex 48037-2200 (SMT, right angle, for 1.6 mm boards): its "PCB edge" line
# sits on the board's front edge and the plug sticks out ~15 mm in front.
usb = pcbnew.FootprintLoad(f"{FPLIB}/Connector_USB.pretty", USB_FP)
usb.SetFPID(pcbnew.LIB_ID("Connector_USB", USB_FP))
place(usb, "J1", "Molex 48037-2200", 0.0, FRONT - 5.625, 90)
for pd in usb.Pads():
    if pd.GetNumber() in ("1", "2", "3", "4"):
        pd.SetNet(nets[{1: "VBUS", 2: "PDM_CLK", 3: "PDM_DAT", 4: "GND"}[int(pd.GetNumber())]])
    elif pd.GetNumber() == "5":
        pd.SetNet(nets["GND"])                       # shell
jpos = {pd.GetNumber(): (round(pcbnew.ToMM(pd.GetPosition().x) - X0, 3), round(pcbnew.ToMM(pd.GetPosition().y) - Y0, 3)) for pd in usb.Pads() if pd.GetNumber() in "1234" and pd.GetNumber()}
print("J1 pads", jpos)
for pin_, net_, x_ in CONTACTS:
    assert abs(jpos[str(pin_)][0] - x_) < 0.01 and abs(jpos[str(pin_)][1] - USB_PAD_Y) < 0.01, jpos

# J2: 1 x 5 right-angle 0.1" header, pads in a row across the board, pins pointing back
hdr = pcbnew.FootprintLoad(f"{FPLIB}/Connector_PinHeader_2.54mm.pretty", "PinHeader_1x05_P2.54mm_Horizontal")
hdr.SetFPID(pcbnew.LIB_ID("Connector_PinHeader_2.54mm", "PinHeader_1x05_P2.54mm_Horizontal"))
place(hdr, "J2", "mic board", 5.08, HDR_Y, -90)
# v3.3: J2 on the BACK (mic sits 4.1 mm lower, close to the USB plug's axis). Flipped left-right so
# its pins still point back; then moved so the row spans the same x positions as before.
hdr.Flip(hdr.GetPosition(), True)
_xs = [pcbnew.ToMM(p.GetPosition().x) - X0 for p in hdr.Pads()]
hdr.Move(VECTOR2I(FromMM(-(min(_xs) + 5.08)), 0))
hpos = {}
for pd in hdr.Pads():
    x = round(pcbnew.ToMM(pd.GetPosition().x) - X0, 3); y = round(pcbnew.ToMM(pd.GetPosition().y) - Y0, 3)
    net = [n for n, hx in HDR.items() if abs(hx - x) < 0.01]
    assert len(net) == 1 and abs(y - HDR_Y) < 0.01, (pd.GetNumber(), x, y)
    pd.SetNet(nets[net[0]]); hpos[net[0]] = (x, y)
bb = hdr.GetBoundingBox(False, False)
print("J2 pads", hpos, "body/pins reach y", round(pcbnew.ToMM(bb.GetBottom()) - Y0, 2))
assert pcbnew.ToMM(bb.GetBottom()) - Y0 > HDR_Y + 9, "J2 pins must point back (+y)"
hp = lambda n: hpos[n]


# ---------------------------------------------------------------- small parts
# R1/R2 on the TOP, in line with J2's DAT and CLK pins; U1, C1, C2 and JP1 on the BACK.
def place_back(fp, ref, value, x, y, rot=0):
    place(fp, ref, value, x, y)
    fp.Flip(fp.GetPosition(), False)
    fp.SetOrientationDegrees(rot)
    return fp
xy = lambda p: (round(pcbnew.ToMM(p.GetPosition().x) - X0, 3), round(pcbnew.ToMM(p.GetPosition().y) - Y0, 3))
def pad(fp, num):
    return [p for p in fp.Pads() if p.GetNumber() == str(num)][0]

CAP = "C_0805_2012Metric_Pad1.18x1.45mm_HandSolder"
RES = "R_0805_2012Metric_Pad1.20x1.40mm_HandSolder"
JPF = "SolderJumper-3_P1.3mm_Bridged12_RoundedPad1.0x1.5mm"
def load(lib, name):
    fp = pcbnew.FootprintLoad(f"{FPLIB}/{lib}.pretty", name)
    fp.SetFPID(pcbnew.LIB_ID(lib, name))
    return fp

R_Y = 13.6
jy = BOARD_L - 1.95           # JP1 / C2 row (back, under J2's body)
R2 = place(load("Resistor_SMD", RES), "R2", "0R", 0.0, 12.9, 0)     # lying across the board, under J1's CLK pad
R1 = place(load("Resistor_SMD", RES), "R1", "0R", HDR["PDM_DAT_MIC"] - 1.0, 14.9, 0)   # right pad straight above J2's DAT pin
U1 = place_back(load("Package_TO_SOT_SMD", "SOT-89-3"), "U1", "XC6206P332PR", -3.0, 14.4, 180)
C1 = place_back(load("Capacitor_SMD", CAP), "C1", "1uF", 1.6, 13.4, 90)
C2 = place(load("Capacitor_SMD", CAP), "C2", "1uF", -4.8, jy, 0)      # top, beside J2 (its body is on the back)
JP1 = place(load("Jumper", JPF), "JP1", "SEL", 0.0, jy, 180)      # top
JP1.SetAttributes(JP1.GetAttributes() | pcbnew.FP_EXCLUDE_FROM_BOM)
drop = [it for it in JP1.GraphicalItems() if it.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS)]
drop += [it for it in U1.GraphicalItems() if it.GetLayer() == pcbnew.B_SilkS and it.GetClass() != "FP_TEXT"]

# XC6206 SOT-89: 1 = GND, 2 = VIN (and the tab), 3 = VOUT
u1 = {n: xy(pad(U1, n)) for n in "123"}
print("U1", u1)
assert u1["1"][1] < u1["2"][1] < u1["3"][1] and u1["1"][0] > -3.0, "U1: pins on the right, GND at the top, OUT at the bottom"
pad(U1, 1).SetNet(nets["GND"]); pad(U1, 2).SetNet(nets["VBUS"]); pad(U1, 3).SetNet(nets["+3V3"])
def by_y(fp): return sorted(fp.Pads(), key=lambda p: p.GetPosition().y)
def by_x(fp): return sorted(fp.Pads(), key=lambda p: p.GetPosition().x)
r2t, r2b = by_x(R2); r2t.SetNet(nets["PDM_CLK"]); r2b.SetNet(nets["PDM_CLK_MIC"])   # left pad in, right pad out
r1t, r1b = by_x(R1); r1t.SetNet(nets["PDM_DAT"]); r1b.SetNet(nets["PDM_DAT_MIC"])
c1t, c1b = by_y(C1); c1t.SetNet(nets["GND"]); c1b.SetNet(nets["VBUS"])          # 5 V pad level with U1's input
c2l, c2r = by_x(C2); c2l.SetNet(nets["GND"]); c2r.SetNet(nets["+3V3"])           # 3V3 pad towards JP1
jp = {p.GetNumber(): p for p in JP1.Pads()}
jp["1"].SetNet(nets["GND"]); jp["2"].SetNet(nets["MIC_SEL"]); jp["3"].SetNet(nets["+3V3"])
print("JP1", {k: xy(v) for k, v in jp.items()}, "C2", xy(c2l), xy(c2r), "C1", xy(c1t), xy(c1b))
assert xy(jp["3"])[0] < xy(jp["2"])[0] < xy(jp["1"])[0], "JP1: 3V3 pad towards C2"

# ---------------------------------------------------------------- routing
def track(points, net, width, layer=pcbnew.F_Cu):
    for a, b in zip(points, points[1:]):
        t = pcbnew.PCB_TRACK(board)
        t.SetStart(P(*a)); t.SetEnd(P(*b))
        t.SetWidth(FromMM(width)); t.SetLayer(layer); t.SetNet(nets[net])
        board.Add(t)

def via(x, y, net):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(P(x, y))
    v.SetWidth(FromMM(0.6)); v.SetDrill(FromMM(0.3))
    v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
    v.SetNet(nets[net])
    board.Add(v)

Bk = pcbnew.B_Cu
# CLK (D-) and DATA (D+): on the top, from J1 to R2 / R1 and straight back to J2
track([(-1.0, USB_PAD_Y), xy(r2t)], "PDM_CLK", 0.3)                                   # straight down
track([(1.0, USB_PAD_Y), (1.0, 11.4), (xy(r1t)[0], 11.4), xy(r1t)], "PDM_DAT", 0.3)        # round the right of R2
track([xy(r2b), (xy(r2b)[0], 16.4), (HDR["PDM_CLK_MIC"], 17.0), hp("PDM_CLK_MIC")], "PDM_CLK_MIC", 0.3)
track([xy(r1b), hp("PDM_DAT_MIC")], "PDM_DAT_MIC", 0.3)
# VBUS: J1 pin 1 -> via -> back -> U1 tab; U1 input pin -> C1
track([(-3.5, USB_PAD_Y), (-3.5, 11.3)], "VBUS", 0.5)
via(-3.5, 11.3, "VBUS")
track([(-3.5, 11.3), (-3.5, 14.4)], "VBUS", 0.6, Bk)   # into U1's tab (= its input)
track([u1["2"], (xy(c1b)[0] - 0.6, u1["2"][1]), xy(c1b)], "VBUS", 0.5, Bk)
# 3V3: U1 output -> via -> top -> J2 3V pin; on the back J2 3V pin -> C2 -> JP1 pad 3
track([u1["3"], (u1["3"][0], 17.3), (HDR["+3V3"] + 0.6, 17.3), hp("+3V3")], "+3V3", 0.4, Bk)   # back: under U1's tab, over the GND pin
track([hp("+3V3"), (-3.9, HDR_Y + 1.3), xy(c2r)], "+3V3", 0.4)
track([hp("GND"), (-1.8, HDR_Y + 1.0)], "GND", 0.4, Bk)   # J2 GND pin: extra link into the back fill (the 3V3 track takes one spoke)
track([xy(c2r), xy(jp["3"])], "+3V3", 0.4)
# SEL: JP1 pad 2 straight to J2; JP1 pad 1 GND out of the fill keep-out
track([xy(jp["2"]), hp("MIC_SEL")], "MIC_SEL", 0.3)
track([xy(jp["1"]), (xy(jp["1"])[0], jy - 1.2)], "GND", 0.3)   # up, out of the fill keep-out
# ground stitching
for x, y in [(-5.0, 11.5), (3.8, 16.2), (6.15, 16.3), (-6.2, 15.6), (3.6, HDR_Y + 2.4), (-2.0, 11.6), (0.3, 15.6)]:
    via(x, y, "GND")

# ---------------------------------------------------------------- ground fills
def zone(layer, poly, net="GND"):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    z.SetNet(nets[net])
    z.SetLocalClearance(FromMM(0.25))
    z.SetMinThickness(FromMM(0.25))
    z.SetThermalReliefGap(FromMM(0.3))
    z.SetThermalReliefSpokeWidth(FromMM(0.4))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
    ol = z.Outline()
    ol.NewOutline()
    for x, y in poly:
        ol.Append(FromMM(X0 + x), FromMM(Y0 + y))
    board.Add(z)
    return z

def rule_area(poly, layers):
    k = pcbnew.ZONE(board)
    k.SetIsRuleArea(True); k.SetLayerSet(layers)
    k.SetDoNotAllowCopperPour(True); k.SetDoNotAllowTracks(False); k.SetDoNotAllowVias(False)
    k.SetDoNotAllowPads(False); k.SetDoNotAllowFootprints(False)
    o = k.Outline(); o.NewOutline()
    for x, y in poly:
        o.Append(FromMM(X0 + x), FromMM(Y0 + y))
    board.Add(k)

zone(pcbnew.F_Cu, [(-bw, FRONT), (bw, FRONT), (bw, L), (-bw, L)])
zone(pcbnew.B_Cu, [(-bw, FRONT), (bw, FRONT), (bw, L), (-bw, L)])
LB = pcbnew.LSET(); LB.AddLayer(pcbnew.B_Cu)
LS2 = pcbnew.LSET(); LS2.AddLayer(pcbnew.F_Cu); LS2.AddLayer(pcbnew.B_Cu)
LF = pcbnew.LSET(); LF.AddLayer(pcbnew.F_Cu)
rule_area([(-2.0, jy - 0.95), (2.0, jy - 0.95), (2.0, jy + 0.95), (-2.0, jy + 0.95)], LF)   # off the solder jumper
# no fill keep-outs at the panel's break-off tabs: the fill stays 0.3 mm from every edge anyway
pcbnew.ZONE_FILLER(board).Fill(board.Zones())

# ---------------------------------------------------------------- silkscreen
F, B = pcbnew.F_SilkS, pcbnew.B_SilkS
for n, lbl in (("+3V3", "3V"), ("GND", "GND"), ("MIC_SEL", "SEL"), ("PDM_CLK_MIC", "CLK"), ("PDM_DAT_MIC", "DAT")):
    add_text(board, lbl, HDR[n], HDR_Y - 1.85, F, size=0.8, thick=0.12)
add_text(board, "J1", -4.6, 13.0, F, size=1.0)
add_text(board, "J2", 4.6, 15.6, B, size=1.0, mirror=True)
add_text(board, "R2", -2.6, 12.9, F, size=0.8, thick=0.12)
add_text(board, "R1", 5.3, 13.3, F, size=0.8, thick=0.12)
add_text(board, "IM73D122 USB", 0.0, 9.8, B, size=1.0, mirror=True)
add_text(board, "v3.3", 3.5, 11.1, B, size=0.8, thick=0.12, mirror=True)
add_text(board, "U1", -0.75, 11.75, B, size=0.8, thick=0.12, mirror=True)
add_text(board, "C1", 3.3, 13.4, B, size=0.8, thick=0.12, mirror=True)
add_text(board, "C2", -4.8, jy + 1.35, F, size=0.8, thick=0.12)
add_text(board, "R", -2.45, jy, F, size=0.8, thick=0.12)
add_text(board, "L", 2.45, jy, F, size=0.8, thick=0.12)

# J2's own silkscreen and fab drawing show the pins out past the back edge: keep only what is on the board
for it in list(hdr.GraphicalItems()):
    if it.GetLayer() in (pcbnew.F_SilkS, pcbnew.F_Fab, pcbnew.B_SilkS, pcbnew.B_Fab) and it.GetClass() != "FP_TEXT":
        if pcbnew.ToMM(it.GetBoundingBox().GetBottom()) - Y0 > BOARD_L - 0.4:
            drop.append(it)
for it in drop:
    it.GetParent().Remove(it)
pcbnew.SaveBoard(OUT, board)
print("saved", OUT)
