"""6 x 7 panel of the IM73D122 PDM adapter for a 100 x 100 mm JLCPCB order.

Each board is the same as build_pdm_pcb.py. Columns are 2.0 mm apart and
rows 1.6 mm apart, joined by one mouse-bite tab per shared edge
(footprints MouseBite_2.0x2.5mm_... and MouseBite_1.6x2.5mm_...: a 2.5 mm
wide bridge across the gap with three 0.5 mm non-plated holes at 0.85 mm
pitch on each side, set just outside the board edge). Break apart and file
the small nubs flush.
"""
import math, os, pcbnew

mm = pcbnew.FromMM
def P(x, y): return pcbnew.VECTOR2I(mm(x), mm(y))

OUT = os.path.abspath("adapter/IM73D122_Adapter.kicad_pcb")
os.makedirs(os.path.dirname(OUT), exist_ok=True)
board = pcbnew.NewBoard(OUT)

COLS, ROWS = 1, 1
W, H, R = 13.97, 12.70, 2.54          # single board size and corner radius
GAP_X = 2.0                            # gap between columns = mouse-bite slot
GAP_Y = 1.6                            # gap between rows (narrower so a 7th row fits)
TAB = 2.5                              # tab width (holes span 2.2 mm, so they stay inside the tab)
HOLE_D, HOLE_P, HOLE_N = 0.5, 0.85, 3  # mouse-bite holes
TAB_Y = 7.0                            # tab centre on left/right edges (clear of the edge via)
TAB_X = W / 2                          # tab centre on top/bottom edges
PX0, PY0 = 100.0, 100.0                # panel top-left

# ---- design rules ----
ds = board.GetDesignSettings()
ds.SetBoardThickness(mm(1.6))
ds.m_CopperEdgeClearance = mm(0.3)
ds.m_TrackMinWidth = mm(0.2)
ds.m_MinClearance = mm(0.2)
ds.m_ViasMinSize = mm(0.5)
ds.m_MinThroughDrill = mm(0.3)
ds.m_MinSilkTextHeight = mm(0.5)
nc = ds.m_NetSettings.m_DefaultNetClass
nc.SetClearance(mm(0.2)); nc.SetTrackWidth(mm(0.5))
nc.SetViaDiameter(mm(0.6)); nc.SetViaDrill(mm(0.3))

def shape(kind, layer, width, filled=False):
    s = pcbnew.PCB_SHAPE(board, kind); s.SetLayer(layer); s.SetWidth(mm(width))
    s.SetFilled(filled); board.Add(s); return s

def seg(layer, a, b, width=0.05):
    l = shape(pcbnew.SHAPE_T_SEGMENT, layer, width); l.SetStart(P(*a)); l.SetEnd(P(*b))

def text(txt, x, y, layer, h, w, t, mirror=False):
    o = pcbnew.PCB_TEXT(board); o.SetText(txt); o.SetLayer(layer)
    o.SetTextSize(P(w, h)); o.SetTextThickness(mm(t)); o.SetPosition(P(x, y))
    o.SetMirrored(mirror); board.Add(o); return o

def new_fp(lib, name, ref, val, pos, attrs=pcbnew.FP_THROUGH_HOLE):
    fp = pcbnew.FOOTPRINT(board)
    fp.SetFPID(pcbnew.LIB_ID(lib, name))
    fp.SetReference(ref); fp.SetValue(val); fp.SetPosition(pos)
    for t in (fp.Reference(), fp.Value()):
        t.SetLayer(pcbnew.F_Fab); t.SetTextSize(P(0.6, 0.6)); t.SetTextThickness(mm(0.1))
        t.SetVisible(False)
    fp.SetAttributes(attrs)
    board.Add(fp); return fp

def place_pad(fp, p, x, y):
    fp.Add(p)
    fpos = fp.GetPosition()
    p.SetPos0(pcbnew.VECTOR2I(mm(x) - fpos.x, mm(y) - fpos.y))
    p.SetPosition(P(x, y))

def add_pad(fp, num, x, y, size, drill, net=None):
    p = pcbnew.PAD(fp)
    p.SetNumber(num); p.SetAttribute(pcbnew.PAD_ATTRIB_PTH)
    p.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
    p.SetSize(P(size, size)); p.SetDrillSize(P(drill, drill))
    p.SetLayerSet(pcbnew.PAD.PTHMask())
    place_pad(fp, p, x, y)
    if net: p.SetNet(net)

def outline(OX, OY, open_l, open_r, open_t, open_b):
    """Rounded-rectangle Edge.Cuts with a TAB-wide opening on each joined side."""
    X0, Y0, X1, Y1 = OX, OY, OX + W, OY + H
    def side(a, b, horiz, fixed, opened, centre):
        if not opened:
            seg(pcbnew.Edge_Cuts, a, b); return
        c0, c1 = centre - TAB / 2, centre + TAB / 2
        if horiz:
            lo, hi = sorted((a[0], b[0]))
            seg(pcbnew.Edge_Cuts, (lo, fixed), (c0, fixed)); seg(pcbnew.Edge_Cuts, (c1, fixed), (hi, fixed))
        else:
            lo, hi = sorted((a[1], b[1]))
            seg(pcbnew.Edge_Cuts, (fixed, lo), (fixed, c0)); seg(pcbnew.Edge_Cuts, (fixed, c1), (fixed, hi))
    side((X0 + R, Y0), (X1 - R, Y0), True, Y0, open_t, OX + TAB_X)
    side((X1 - R, Y1), (X0 + R, Y1), True, Y1, open_b, OX + TAB_X)
    side((X0, Y1 - R), (X0, Y0 + R), False, X0, open_l, OY + TAB_Y)
    side((X1, Y0 + R), (X1, Y1 - R), False, X1, open_r, OY + TAB_Y)
    k = R * (1 - math.sqrt(0.5))
    for s, m, e in [((X0, Y0 + R), (X0 + k, Y0 + k), (X0 + R, Y0)),
                    ((X1 - R, Y0), (X1 - k, Y0 + k), (X1, Y0 + R)),
                    ((X1, Y1 - R), (X1 - k, Y1 - k), (X1 - R, Y1)),
                    ((X0 + R, Y1), (X0 + k, Y1 - k), (X0, Y1 - R))]:
        c = shape(pcbnew.SHAPE_T_ARC, pcbnew.Edge_Cuts, 0.05)
        c.SetArcGeometry(P(*s), P(*m), P(*e))

def adapter(OX, OY, n, opens):
    """One complete adapter at (OX, OY); nets and references get suffix n."""
    def A(x, y): return (OX + x, OY + y)
    CX, CY = A(6.985, 6.05)
    HY = OY + 10.16
    HXS = [OX + 1.905 + 2.54 * i for i in range(5)]
    nets = {}
    for name in ["GND", "DAT", "CLK", "+3V3", "SEL"]:
        ni = pcbnew.NETINFO_ITEM(board, f"{name}_{n}"); board.Add(ni); nets[name] = ni

    j = new_fp("IM73D122_Adapter", "PinHeader_1x05_P2.54mm", f"J{n}", "3V GND SEL CLK DAT", P(HXS[2], HY))
    for i, net in enumerate(["+3V3", "GND", "SEL", "CLK", "DAT"]):
        add_pad(j, str(i + 1), HXS[i], HY, 1.68, 1.0, nets[net])
    u = new_fp("IM73D122_Adapter", "IM73D122_Module", f"U{n}", "IM73D122", P(CX, CY))
    for num, dx, dy, net in [("1", -4, -2, "+3V3"), ("2", -4, 0, "GND"), ("3", -4, 2, None),
                             ("4", 4, -2, "SEL"), ("5", 4, 0, "CLK"), ("6", 4, 2, "DAT")]:
        add_pad(u, num, CX + dx, CY + dy, 1.4, 0.8, nets[net] if net else None)

    outline(OX, OY, *opens)

    RO = 6.0
    def arc_pt(dy, s): return (CX + s * math.sqrt(RO * RO - dy * dy), CY + dy)
    for s in (-1, 1):
        a = shape(pcbnew.SHAPE_T_ARC, pcbnew.F_SilkS, 0.12)
        a.SetArcGeometry(P(*arc_pt(-3.8, s)), P(*arc_pt(-0.75, s)), P(*arc_pt(2.6, s)))
    c = shape(pcbnew.SHAPE_T_CIRCLE, pcbnew.F_SilkS, 0.12, filled=True)
    c.SetStart(P(CX, CY)); c.SetEnd(P(CX + 0.3, CY))
    text("Mic port up", CX, CY + 0.95, pcbnew.F_SilkS, 0.5, 0.5, 0.1)
    o = shape(pcbnew.SHAPE_T_CIRCLE, pcbnew.F_SilkS, 0.12)
    o.SetStart(P(CX - 5.45, CY - 2.0)); o.SetEnd(P(CX - 5.15, CY - 2.0))   # pin-1 dot left of pin 1
    text("IM73D122 Adapter", CX, OY + 1.25, pcbnew.F_SilkS, 1.2, 0.62, 0.15)
    for lbl, x in zip(["3V", "GND", "SEL", "CLK", "DAT"], HXS):
        text(lbl, x, OY + 11.85, pcbnew.F_SilkS, 0.6, 0.55, 0.12)
        text(lbl, x, OY + 11.85, pcbnew.B_SilkS, 0.6, 0.55, 0.12, mirror=True)

    def track(pts, layer, net):
        for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
            tr = pcbnew.PCB_TRACK(board)
            tr.SetStart(P(x1, y1)); tr.SetEnd(P(x2, y2)); tr.SetWidth(mm(0.5))
            tr.SetLayer(layer); tr.SetNet(nets[net]); board.Add(tr)
    track([(CX - 4, CY - 2), (OX + 1.2, CY - 2), A(1.2, 9.455), (HXS[0], HY)], pcbnew.B_Cu, "+3V3")
    track([(CX + 4, CY), (HXS[3], CY + 1.46), (HXS[3], HY)], pcbnew.B_Cu, "CLK")
    track([(CX + 4, CY + 2), (HXS[4], HY)], pcbnew.B_Cu, "DAT")
    track([(CX + 4, CY - 2), (CX + 2.015, CY - 0.015), (CX + 2.015, OY + 8.175), (HXS[2], HY)], pcbnew.F_Cu, "SEL")

    for x, y in [(5.0, 4.0), (8.2, 4.0), (5.0, 8.5), (7.0, 3.0), (13.35, 5.5)]:
        v = pcbnew.PCB_VIA(board)
        v.SetPosition(P(*A(x, y))); v.SetWidth(mm(0.6)); v.SetDrill(mm(0.3))
        v.SetViaType(pcbnew.VIATYPE_THROUGH); v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        v.SetNet(nets["GND"]); board.Add(v)

    # GND fill: zone inset 0.3 mm so copper never reaches the break line at a tab
    e = 0.3
    for layer in (pcbnew.F_Cu, pcbnew.B_Cu):
        z = pcbnew.ZONE(board)
        z.SetLayer(layer); z.SetNet(nets["GND"])
        z.SetLocalClearance(mm(0.25)); z.SetMinThickness(mm(0.2))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
        z.SetThermalReliefGap(mm(0.3)); z.SetThermalReliefSpokeWidth(mm(0.4))
        ol = z.Outline(); ol.NewOutline()
        for x, y in [(e, e), (W - e, e), (W - e, H - e), (e, H - e)]:
            ol.Append(*[mm(v) for v in A(x, y)])
        board.Add(z)

tabs = 0
def mousebite(cx, cy, vertical_gap):
    """Tab centred at (cx, cy). vertical_gap=True: gap runs up/down between
    left and right boards (tab spans x); False: gap between rows (tab spans y)."""
    global tabs
    tabs += 1
    fp = new_fp("IM73D122_Panel", "MouseBite_" + (f"{GAP_X:.1f}" if vertical_gap else f"{GAP_Y:.1f}") + "x2.5mm_outset_D0.5mm_P0.85mm_3h",
                f"MB{tabs}", "MouseBite", P(cx, cy), pcbnew.FP_EXCLUDE_FROM_BOM | pcbnew.FP_EXCLUDE_FROM_POS_FILES)
    g, t = (GAP_X if vertical_gap else GAP_Y) / 2, TAB / 2
    def rot(u, v): return (cx + u, cy + v) if vertical_gap else (cx + v, cy + u)
    # tab sides (Edge.Cuts) across the gap
    for v in (-t, t):
        s = pcbnew.FP_SHAPE(fp, pcbnew.SHAPE_T_SEGMENT)
        s.SetLayer(pcbnew.Edge_Cuts); s.SetWidth(mm(0.05))
        a, b = rot(-g, v), rot(g, v)
        s.SetStart0(pcbnew.VECTOR2I(mm(a[0] - cx), mm(a[1] - cy)))
        s.SetEnd0(pcbnew.VECTOR2I(mm(b[0] - cx), mm(b[1] - cy)))
        fp.Add(s); s.SetDrawCoord()
    # holes: tangent to each board edge, on the tab side ("outset")
    off = g - HOLE_D / 2
    for u in (-off, off):
        for i in range(HOLE_N):
            v = (i - (HOLE_N - 1) / 2) * HOLE_P
            p = pcbnew.PAD(fp)
            p.SetNumber(""); p.SetAttribute(pcbnew.PAD_ATTRIB_NPTH)
            p.SetShape(pcbnew.PAD_SHAPE_CIRCLE)
            p.SetSize(P(HOLE_D, HOLE_D)); p.SetDrillSize(P(HOLE_D, HOLE_D))
            p.SetLayerSet(pcbnew.PAD.UnplatedHoleMask())
            place_pad(fp, p, *rot(u, v))

n = 0
for r in range(ROWS):
    for c in range(COLS):
        n += 1
        OX, OY = PX0 + c * (W + GAP_X), PY0 + r * (H + GAP_Y)
        adapter(OX, OY, n, (c > 0, c < COLS - 1, r > 0, r < ROWS - 1))
        if c < COLS - 1:
            mousebite(OX + W + GAP_X / 2, OY + TAB_Y, True)
        if r < ROWS - 1:
            mousebite(OX + TAB_X, OY + H + GAP_Y / 2, False)

board.BuildConnectivity()
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
pcbnew.SaveBoard(OUT, board)
pcbnew.WriteDRCReport(board, os.path.join(os.path.dirname(OUT), "drc.rpt"), pcbnew.EDA_UNITS_MILLIMETRES, True)
pw, ph = COLS * W + (COLS - 1) * GAP_X, ROWS * H + (ROWS - 1) * GAP_Y
print(f"saved {OUT}: {COLS}x{ROWS} = {COLS*ROWS} boards, {tabs} tabs, panel {pw:.2f} x {ph:.2f} mm")
