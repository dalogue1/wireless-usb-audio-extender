#!/usr/bin/env python3
"""Builds IM73D122_USB_A_Panel: 12 sets, each a v3.3 USB-A board plus its own IM73D122 adapter
board, all joined by mouse-bite tabs, within 100 x 100 mm.

Per column, top to bottom: USB board (plug up), its adapter, a second adapter (turned 180),
the second USB board (turned 180, plug down). So each USB board sits next to an adapter, the
two adapters meet in the middle, and the plugs face out at the panel's top and bottom edges
(nothing to clash with). Side tabs join the columns.

Needs KiCad 7 (pcbnew) and KiKit 1.6 on python3.12. Run from the project folder:
  python3.12 tools/make_board.py IM73D122_USB_A/IM73D122_USB_A.kicad_pcb
  python3.12 tools/make_adapter.py          (adapter/IM73D122_Adapter.kicad_pcb, one adapter)
  python3.12 tools/make_combo_panel.py
"""
import json
import os
import shutil
import subprocess
import sys

USB_SRC = "IM73D122_USB_A/IM73D122_USB_A.kicad_pcb"
ADP_SRC = "adapter/IM73D122_Adapter.kicad_pcb"
OUT = "IM73D122_USB_A_Panel/IM73D122_USB_A_Panel.kicad_pcb"
TMP = "build/panel_src"

COLS = 6
PITCH_X = 16.0                 # 14.0 mm boards + 2.0 mm gap
GAP = 2.0
USB_L, ADP_L = 18.5, 12.7      # board lengths

# Tab annotations are added in a separate Python: pcbnew footprint edits misbehave once KiKit
# is loaded in the same process.
ADD_TABS = r"""
import sys, json, os, pcbnew
from pcbnew import VECTOR2I, FromMM
path, lib, width, tabs = sys.argv[1], sys.argv[2], sys.argv[3], json.loads(sys.argv[4])
b = pcbnew.LoadBoard(path)
for i, (x, y, rot) in enumerate(tabs, 1):
    fp = pcbnew.FootprintLoad(lib, "Tab")
    fp.SetFPID(pcbnew.LIB_ID("kikit", "Tab"))
    fp.SetReference(f"KIKIT_TAB{i}")
    fp.SetPosition(VECTOR2I(FromMM(x), FromMM(y)))
    fp.SetOrientationDegrees(rot)
    for t in fp.GraphicalItems():
        if isinstance(t, pcbnew.FP_TEXT) and t.GetText().startswith("KIKIT:"):
            t.SetText(f"KIKIT: width: {width}mm")
    b.Add(fp)
drop = []
for fp in b.GetFootprints():    # parts that hang past the edges (J1 plug, J2 pins): drop their outlines
    if fp.GetReference() in ("J1", "J2"):
        for it in fp.GraphicalItems():
            if it.GetLayer() in (pcbnew.F_CrtYd, pcbnew.B_CrtYd, pcbnew.F_Fab, pcbnew.B_Fab, pcbnew.Dwgs_User):
                drop.append((fp, it))
for fp, it in drop:
    fp.Remove(it)
pcbnew.SaveBoard(path, b)
"""
LIB = subprocess.run([sys.executable, "-c", "import kikit, os; print(os.path.join(os.path.dirname(kikit.__file__), 'resources', 'kikit.pretty'))"],
                     check=True, capture_output=True, text=True).stdout.strip()


def add_tabs(path, tabs, width):
    """(x, y, rot) on the board edge, pointing INTO the board
    (0 = towards +x, 180 = towards -x, 90 = towards -y, -90 = towards +y)."""
    subprocess.run([sys.executable, "-c", ADD_TABS, path, LIB, str(width), json.dumps(tabs)], check=True)


if os.path.isdir(TMP):
    shutil.rmtree(TMP)
os.makedirs(TMP)
usb = os.path.join(TMP, "usb.kicad_pcb")
adp = os.path.join(TMP, "adapter.kicad_pcb")
shutil.copy(USB_SRC, usb)
shutil.copy(ADP_SRC, adp)
# USB board (page origin 100, 80; board x -7..7, y 4.3..22.8): side tabs beside the plug (3 mm),
# and one in the middle of the back edge (2.5 mm), lined up with the adapter's own tab so the two
# make a single bridge. The board keeps its fill off the whole back-edge strip.
add_tabs(usb, [(107.0, 90.4, 180), (93.0, 90.4, 0), (100.0, 102.8, 90)], 2.5)
# Adapter (100..113.97 x 100..112.7): one tab per side, where its own panel had them
# (2.5 mm wide; its ground fill is kept clear there).
add_tabs(adp, [(113.97, 107.0, 180), (100.0, 107.0, 0), (106.985, 100.0, -90), (106.985, 112.7, 90)], 2.5)

import pcbnew                                   # noqa: E402  (after the subprocess edits)
from kikit.panelize import Panel, Origin        # noqa: E402
from pcbnew import VECTOR2I, FromMM as mm       # noqa: E402


def area(path):
    return pcbnew.LoadBoard(path).GetBoardEdgesBoundingBox()


usb_area, adp_area = area(usb), area(adp)
panel = Panel(OUT)
panel.inheritDesignSettings(pcbnew.LoadBoard(USB_SRC))
panel.inheritProperties(pcbnew.LoadBoard(USB_SRC))
panel.board.GetDesignSettings().m_CopperEdgeClearance = mm(0.3)   # as on the boards themselves

X0, Y0 = 100.0, 80.0
ys = [USB_L / 2,
      USB_L + GAP + ADP_L / 2,
      USB_L + 2 * GAP + ADP_L + ADP_L / 2,
      USB_L + 3 * GAP + 2 * ADP_L + USB_L / 2]
for c in range(COLS):
    cx = X0 + 7.0 + c * PITCH_X
    for row, (src, ar, rot) in enumerate([(usb, usb_area, 0), (adp, adp_area, 0), (adp, adp_area, 180), (usb, usb_area, 180)]):
        panel.appendBoard(src, VECTOR2I(mm(cx), mm(Y0 + ys[row])), sourceArea=ar, origin=Origin.Center,
                          rotationAngle=pcbnew.EDA_ANGLE(rot, pcbnew.DEGREES_T), tolerance=mm(16),
                          inheritDrc=(src == usb))   # the USB board's design rules; KiKit can't merge two sets
panel.buildPartitionLineFromBB()
cuts = panel.buildTabsFromAnnotations(fillet=0)
panel.makeMouseBites(cuts, diameter=mm(0.5), spacing=mm(0.8), offset=mm(-0.2), prolongation=mm(0.5))
panel.addMillFillets(mm(0.5))
panel.save()
print("panel done:", OUT, len(cuts), "tab cuts")

# The panel project gets KiKit's default rules; use the boards' own: 0.3 mm copper to edge, and
# 0.5 mm text (the adapter's labels are 0.5-0.6 mm, as on its own panel).
pro = OUT.replace(".kicad_pcb", ".kicad_pro")
with open(pro) as f:
    d = json.load(f)
rules = d["board"]["design_settings"]["rules"]
rules["min_copper_edge_clearance"] = 0.3
rules["min_text_height"] = 0.5
with open(pro, "w") as f:
    json.dump(d, f, indent=2)
