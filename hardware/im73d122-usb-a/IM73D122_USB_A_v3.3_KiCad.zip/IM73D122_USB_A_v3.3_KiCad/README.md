# IM73D122 USB-A mic board v3.3

A small PCB with a soldered-on USB-A plug (J1, Molex 48037-2200) at the front and a 1 × 5 right-angle 0.1" header (J2) at the back. A mic board stands on J2 at 90°, facing straight out of the back: Dan's IM73D122 adapter board, or an Adafruit PDM MEMS microphone breakout (same size and pin order: 3V, GND, SEL, CLK, DAT). The board also carries the 3.3 V regulator. Plugged into the USB-A socket of an OTG adapter on a XIAO ESP32-S3, the S3 reads the mic **directly over the USB data lines used as ordinary GPIOs**. This is not USB: no USB chip, no protocol.

| J1 pin | Signal | ESP32-S3 | Mic |
|---|---|---|---|
| 1 VBUS | 5 V | (from the adapter) | → XC6206 → 3.3 V |
| 2 D− | PDM clock | GPIO19 | CLK (through R2) |
| 3 D+ | PDM data | GPIO20 | DATA (through R1) |
| 4 GND | ground | GND | GND |

J2 (mic board) pins, left to right as printed on the top: **3V, GND, SEL, CLK, DAT**.

SEL goes to solder jumper JP1 on the top, just behind J2's pins: **bridged to GND (left channel) as made**. To switch the mic to the right channel, cut the thin bridge between the L pad and the middle pad, then solder-bridge the middle pad to the R pad (3.3 V). With one mic per S3 either setting works, as long as the firmware reads (or auto-detects) the matching channel.

| Top | Back |
|---|---|
| ![top](images/board_top.png) | ![back](images/board_bottom.png) |

## Board

* 14.0 × 18.5 mm, standard **1.6 mm** thickness, any surface finish (HASL is fine), 2 layers. The plug sticks out about 15 mm in front of the board.
* J1: Molex 48037-2200 surface-mount USB-A plug, unchanged from v3.2.
* J2: 1 × 5 right-angle pin header, 2.54 mm (0.1") pitch, on the **back** at the back edge (so the mic sits close to the USB plug's axis). Its plastic body rests on the board and its front face is flush with the back edge (pin row 4.04 mm from the edge: 1.5 mm to the body plus the 2.54 mm body, as in KiCad's footprint). The pins stick out about 6 mm past the edge, so the mic board can sit right against the body and the board edge, with pin length to spare.
* **The mic board goes on J2 standing upright, with its pin row at the bottom and its mic side facing away from this board.** Seen from the front of the mic, the mic board reads 3V GND SEL CLK DAT from left to right, the same as the labels above J2 seen from behind. The IM73D122 is centred on the adapter, which puts the mic about 1 mm below the centre line of the USB plug (whose 4.5 mm shell rests on the top surface). The adapter and an Adafruit PDM breakout give the same height.
* Push the pins through the mic board from its back (the side facing this board) and solder them on its back. If the IM73D122 module is already fitted, keep the pin ends short of the module.
* On the **top**: R1 and R2, lying across the board near its centre (R2 right under J1's CLK pad, R1 below it with its output pad straight above the DAT pin), and C2 and JP1 just behind J2's pins. On the **back**: U1 and C1, and J2's plastic body. JP1 drives the mic board's SEL pin: GND (left channel) as made, 3V3 (right) after cutting and re-bridging. The firmware finds the channel either way.
* Copper: 0.3 mm signal tracks, 0.25 mm minimum gap, 0.3 mm from the board edge; ground fills on both sides. CLK and DATA stay on the top from J1 through R2/R1 to J2.
* Checked: KiCad DRC (0 errors, 0 unconnected; the only warnings are about library names in the checking setup).

## Parts (hand-solderable)

| Ref | Part | Package | Notes |
|---|---|---|---|
| J1 | Molex 48037-2200 USB-A plug | SMT + 2 shell tabs, top | DigiKey WM3983CT-ND, also Mouser, RS (800-6772), Farnell. Not interchangeable with other USB-A plugs: pad and tab positions differ |
| U1 | XC6206P332PR 3.3 V LDO | SOT-89, back | pins 1 GND, 2 IN (and the tab), 3 OUT. LCSC C545581 (UMW) or C41322 (Torex), DigiKey 4518-XC6206P332PRCT-ND. Check a copy's datasheet pinout first |
| C1, C2 | 1 µF ceramic, X5R/X7R, ≥ 10 V | 0805, C1 back, C2 top | C1 = input, C2 = output |
| R1 | 0 Ω (standard) or 33–100 Ω | 0805, top | series resistor in the DATA line. **Must be fitted**: without it the mic is disconnected. Use 33–100 Ω only if a long USB extension gives clicks or noise |
| JP1 | solder jumper (no part) | top | channel select: L (as made) or R |
| R2 | 0 Ω (standard) or 33–100 Ω | 0805, top | series resistor in the CLK line. **Must be fitted**. 33–100 Ω limits overshoot into the mic's clock input on a long cable |
| J2 | 1 × 5 right-angle pin header, 2.54 mm pitch | through-hole, back | any standard right-angle 0.1" header (cut from a strip) |
| — | mic board: IM73D122 adapter (with the IM73D122 module) or Adafruit PDM MEMS breakout | soldered onto J2 | upright: pin row at the bottom, mic side facing out |

Solder U1 and C1 on the back first, then R1, R2 and C2 on the top, then J1 (signal pads on the top, shell tabs from the back), then J2 on the back (soldered from the top), then the mic board onto J2.

## Ordering (JLCPCB)

`IM73D122_USB_A_panel_gerbers.zip` is a panel of **12 sets**: 12 USB boards and 12 IM73D122 adapter boards (6 columns × 4 rows, 94.1 × 68.5 mm, inside the 100 × 100 mm base-price size). Each USB board has its own adapter next to it. Upload it as it is, 1.6 mm, HASL, and mark it as a "panel by customer" with 24 boards (12 + 12). `IM73D122_USB_A_gerbers.zip` is a single USB board without an adapter.

Panel layout, no rails, top to bottom in each column: USB board (plug up), its adapter, a second adapter (turned round), the second USB board (plug down). The plugs face out at the panel's top and bottom edges. Every joint is a mouse-bite tab: USB board to adapter and adapter to adapter at the middle of the edge (2.5 mm), side by side between the columns (3 mm beside the USB plugs, 2.5 mm across the adapters). The boards keep their copper clear of every tab.

The adapter is generated by `tools/make_adapter.py` (Dan's adapter panel script set to a single board). The IM73D122 module stays centred on the board (centre 6.05 mm from the top edge). Two small changes from the original adapter: the pin-1 dot sits beside pin 1, and one ground via moved 0.8 mm (from x 9.0 to 8.2) to clear the SEL track.

## Use

* The OTG adapter must be a plain wired adapter. One with a hub chip inside won't pass the signals through.
* The S3's USB port is then no longer USB: to flash new firmware, unplug the mic board and hold BOOT while plugging in the XIAO.

## Firmware notes (S3 side, not included here)

* Release GPIO19/20 from the USB-Serial-JTAG peripheral (USB Mode "Hardware CDC and JTAG" with CDC On Boot disabled, then reconfigure the pins) and **turn off its D+ pull-up**, which otherwise sits on the data line.
* I2S PDM receive: CLK = GPIO19, DATA = GPIO20, 3.072 MHz clock (48 kHz).
* Set GPIO19 (CLK) to the weakest drive strength (`gpio_set_drive_capability(GPIO_NUM_19, GPIO_DRIVE_CAP_0)`): softer clock edges, less ringing and less crosstalk into DATA on a cable. It is the clock-side counterpart of R1.
* Pick the mic's slot by signal variation, not raw energy: an idle slot held high by a pull-up looks loud by energy alone.

## Extension cables

A short passive USB-A extension (up to about 1 m) should work with R1 = 0 Ω. Longer runs are untested: D+ and D− are a twisted pair, so the 3.072 MHz clock couples into the data wire, and the cable loads the mic's output. Errors show up as clicks or noise bursts, not duller sound. Try R1 and R2 = 33–100 Ω if that happens. Active (repeater) extensions won't work.

## Changes

* v3.3: the front-edge fill keep-outs (for v3.2's front break-off tabs) removed: they left a thin strip of copper reaching the front edge in the middle. The IM73D122 module is no longer on this board. A 1 × 5 right-angle 0.1" header (J2) at the back edge takes a standing mic board (the IM73D122 adapter or an Adafruit PDM breakout), facing straight out of the back. With the module's six pins gone the parts are rearranged and the board is shorter: 14.0 × 18.5 mm (was 20.7). R1/R2 moved to the top, lying across the board near its centre; U1 turned and moved forward. J2 is on the back with its body flush with the back edge, which puts the mic about 1 mm below the USB plug's centre line; C2 and JP1 are on the top behind J2's pins. The panel now holds 12 USB boards, each with an IM73D122 adapter board alongside it (24 boards in all).

* v3.2: U1 changed from SOT-23 to SOT-89 (XC6206P332PR), easier to hand-solder. Board size unchanged. U1 and C2 moved down slightly, C1 up 0.3 mm, 5 V now feeds the tab from above, U1 label sideways beside it, U1 outline dropped.

* v3.1 (J1 label): "J1" added on the top silkscreen beside the USB plug, matching the docs.
* v3.1 (silk fix): all silkscreen at least 0.18 mm from pads (JLCPCB check). R1 and R2 moved up 0.4 mm to make room for the L label above JP1; R moved down; U1 and C1 labels nudged; U1's silk outline dropped where it crowded the pads.
* v3.1 (panel fix): every side bridge now has mouse bites on both ends (the first and last columns were missing one row, and stray holes sat on the panel's outer edge). All mouse-bite holes now sit on the bridges, just outside the board edges, instead of 0.2 mm into the boards. Board unchanged.
* v3.1: fixes from JLCPCB review. JP1 moved 0.15 mm toward the edge (gap to the module pins 0.3 → 0.45 mm). The side break-off tabs moved forward, away from JP1, to sit beside the connector. The ground fill is kept clear of every mouse-bite hole (it overlapped them by 0.15 mm; now ≥0.45 mm clearance).
* v3.0 (panel update): 24 boards per panel (was 10), no rails; board unchanged.
* v3.0: the edge-finger plug (needed a 2.0 mm board and a hard-wearing finish) replaced by a solder-on Molex 48037-2200 USB-A plug on a standard 1.6 mm board; board 14 × 20.7 mm; everything behind the contacts unchanged.
* v2.9: R2 label turned sideways to match R1.
* v2.8: SEL now goes through 3-pad solder jumper JP1 (back, beside the right pin column), bridged to GND (left channel) as made; DATA to the mic runs on the top after R1 to make room.
* v2.7: C2 moved 0.7 mm closer to U1.
* v2.6: 3.3 V runs straight from U1's output to the module's pin 1 (no longer round the outside of the pin column).
* v2.5: R2 moved 0.3 mm inward so the CLK track runs straight down to the mic; the incoming CLK track enters the side of R2's pad.
* v2.4: U1 and C2 labels placed horizontally under their parts.
* v2.3: U1 moved 2 mm towards the contacts, leaving more room between U1 and C2.
* v2.2: U1 turned 90° (input towards the contacts, output towards C2) and C2 turned 180°, so the 5 V and 3.3 V paths are short and direct.
* v2.1: C1 moved to the outside of the 5 V track, above the pin-1 column; R2 level with R1.
* v2.0: R2, a 0805 series resistor in the CLK line (back side); CLK now runs on the back, so the top carries only the module.
* v1.9: 3.3 V track now runs round the outside of the left pin column; the 5 V track between the columns is wider (0.6 mm) with more clearance.
* v1.8: ground via moved off the C1 label on the back.
* v1.7: vias behind the contacts moved 1.5 mm back, so the note on the back has a clear gap under the title.
* v1.6: R1 moved up the DATA line to C1's level, away from the module's pin joints (easier to solder).
* v1.5: "Contacts face socket tongue" note moved up on the back, just under the title.
* v1.4: contact labels (5V, D−, D+, GND) moved to the front, behind each contact; the "Contacts face socket tongue" note stays on the back.
* v1.3: all small parts moved to the back (U1, C1, C2 between the module's pin columns); module moved forward for its real 15.5 mm size; board shortened from 29.5 to 25.0 mm; CLK now runs on the top.
* v1.2: part labels on the top silkscreen (U1, C1, C2, U2; R1 on the back).
* v1.1: R1, a 0805 series resistor on DATA at the mic (back side). Board size unchanged.
* v1.0: first version.

## Files

```
IM73D122_USB_A/         KiCad 7 board
adapter/                KiCad 7 IM73D122 adapter board (the one in the panel)
IM73D122_USB_A_Panel/   KiCad 7 panel (KiKit)
images/                 previews
tools/                  scripts that generate everything (build.sh runs them all: KiCad 7, KiKit 1.6)
```

The JLCPCB-ready Gerber + drill zips (single board and panel) are a separate download.
